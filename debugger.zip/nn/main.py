from debugger import Debugger

# Initialize the debugger with the target script
debugger = Debugger("test_script.py")

# Set breakpoints and watch variables
debugger.set_breakpoint(3)  # Breakpoint at line 3
debugger.set_breakpoint(6)  # Breakpoint at line 6
debugger.watch_variable("x")  # Watch the variable 'x'
debugger.watch_variable("result")  # Watch the variable 'result'


