import pytest
from debugger import Debugger

def test_debugger_breakpoint():
    debugger = Debugger("test_script.py")
    debugger.set_breakpoint(5)
    assert 5 in debugger.breakpoints

def test_debugger_watch_variable():
    debugger = Debugger("test_script.py")
    debugger.watch_variable("total")
    assert isinstance(debugger.watch_vars, object)
    assert "total" in debugger.watch_vars
